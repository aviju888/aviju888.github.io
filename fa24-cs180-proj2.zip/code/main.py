import os 
import numpy as np
import cv2
from scipy import signal
from scipy.ndimage import gaussian_filter
import matplotlib.pyplot as plt

# ##############################################################################
# ############### CONFIG AND IMAGE LOADING #####################################

# FOR THE HYBRID IMAGES
sig_high = 4
sig_low = 2

script_dir = os.path.dirname(os.path.abspath(__file__))
images_dir = os.path.join(script_dir, '..', 'images')

# DEFAULT IMAGES
cameraman = cv2.imread(os.path.join(images_dir, 'cameraman.png'), 0)
image1 = cv2.imread(os.path.join(images_dir, 'apple.jpeg'), 0)
image2 = cv2.imread(os.path.join(images_dir, 'orange.jpeg'), 0)

# FOR CUSTOM IMAGES
cim1 = 'custom.jpg'
cim2 = 'ball.png'
custom_img1 = cv2.imread(os.path.join(images_dir, cim1), 0)
custom_img2 = cv2.imread(os.path.join(images_dir, cim2), 0)

# ##############################################################################
# ############### HELPERS ######################################################

def show_image(image, title='Image', cmap='gray'):
    """Helper function to display an image using matplotlib."""
    plt.imshow(image, cmap=cmap)
    plt.title(title)
    plt.axis('off')
    plt.show()

def align_images(image1, image2):
    h1, w1 = image1.shape[:2]
    h2, w2 = image2.shape[:2]
    h = min(h1, h2)
    w = min(w1, w2)
    starty1 = (h1 - h) // 2
    startx1 = (w1 - w) // 2
    starty2 = (h2 - h) // 2
    startx2 = (w2 - w) // 2
    image1_cropped = image1[starty1:starty1 + h, startx1:startx1 + w]
    image2_cropped = image2[starty2:starty2 + h, startx2:startx2 + w]
    return image1_cropped, image2_cropped

def blend_images(mask, laplacian1, laplacian2):
    return mask * laplacian1 + (1 - mask) * laplacian2

def reconstruct_from_pyramid(pyramid):
    image = pyramid[-1]
    for i in range(len(pyramid) - 2, -1, -1):
        image = pyramid[i] + gaussian_filter(image, sigma=2)
    return image

def convolve2d(image, kernel):
    return signal.convolve2d(image, kernel, mode='same', boundary='symm')

def fourier_transform(image):
    # 2d ft
    f = np.fft.fft2(image)
    fshift = np.fft.fftshift(f)
    magnitude_spectrum = 20 * np.log(np.abs(fshift) + 1) # helps visualization

    plt.figure(figsize=(12, 6))

    plt.subplot(1, 2, 1)
    plt.imshow(image, cmap='gray')
    plt.title('Input Image')
    plt.axis('off')

    plt.subplot(1, 2, 2)
    plt.imshow(magnitude_spectrum, cmap='gray')
    plt.title('Magnitude Spectrum')
    plt.axis('off')

    plt.show()

# ##############################################################################
# ############### PART 1: FUN W/ FILTERS #######################################
# Part 1.1: Finite Difference Operator

def finite_diff(image):
    Dx = np.array([[1, -1], [0, 0]])
    Dy = np.array([[1, 0], [-1, 0]])  

    grad_x = convolve2d(image, Dx)
    grad_y = convolve2d(image, Dy)

    grad_mag = np.sqrt(grad_x**2 + grad_y**2)
    
    # binarize gradient mag, highlight edges
    threshold = np.percentile(grad_mag, 90)
    edge_image = grad_mag > threshold

    show_image(grad_x, 'Gradient X')
    show_image(grad_y, 'Gradient Y')
    show_image(grad_mag, 'Gradient Magnitude')
    show_image(edge_image, 'Binarized Edge Image')

# Part 1.2: Derivative of Gaussian (DoG)
def deriv_of_gaussian(image, sigma=1):
    G = cv2.getGaussianKernel(ksize=5, sigma=sigma)
    G2d = G @ G.T

    blurred_image = convolve2d(image, G2d)

    Dx = np.array([[1, -1], [0, 0]])
    Dy = np.array([[1, 0], [-1, 0]])

    grad_x = convolve2d(blurred_image, Dx)
    grad_y = convolve2d(blurred_image, Dy)
    grad_mag = np.sqrt(grad_x**2 + grad_y**2)

    DoG_x = convolve2d(G2d, Dx)
    DoG_y = convolve2d(G2d, Dy)

    show_image(DoG_x, 'DoG Filter X')
    show_image(DoG_y, 'DoG Filter Y')
    show_image(grad_x, 'Gradient X Derivative of Gaussian')
    show_image(grad_y, 'Gradient Y Derivative of Gaussian')
    show_image(grad_mag, 'Gradient Magnitude Derivative of Gaussian')

# ##############################################################################
# ############### PART 2: FUN WITH FREQUENCIES #################################
# Part 2.1: Image Sharpening
# enhance using high freqs

def unsharp_mask(image, sigma=1.0, strength=1.5):
    G = cv2.getGaussianKernel(ksize=5, sigma=sigma)
    G2d = G @ G.T

    blurred = convolve2d(image, G2d)
    high_freq = image - blurred

    sharpened = strength * high_freq + image

    show_image(image, 'Original Image')
    show_image(blurred, 'Blurred Image')
    show_image(sharpened, 'Sharpened Image')

# Part 2.2: Hybrid Images
# use low and high freqs

def hybrid(image1, image2, sigma_low, sigma_high):
    # aligning
    h1, w1 = image1.shape[:2]
    h2, w2 = image2.shape[:2]

    h = min(h1, h2)
    w = min(w1, w2)

    starty1 = (h1 - h) // 2
    startx1 = (w1 - w) // 2
    starty2 = (h2 - h) // 2
    startx2 = (w2 - w) // 2

    image1_cropped = image1[starty1:starty1 + h, startx1:startx1 + w]
    image2_cropped = image2[starty2:starty2 + h, startx2:startx2 + w]

    # filter
    low_pass = gaussian_filter(image1_cropped, sigma=sigma_low)
    blurred_image2 = gaussian_filter(image2_cropped, sigma=sigma_high)
    high_pass = image2_cropped - blurred_image2

    hybrid = low_pass + high_pass 

    show_image(low_pass, 'Low-pass Image')
    show_image(high_pass, 'High-pass Image')
    show_image(hybrid, 'Hybrid Image')


# Part 2.3: Gaussian and Laplacian Stacks
def gaussian_stack(image, num_levels=5):
    gaussian_pyramid = [image]
    for _ in range(num_levels - 1):
        image = gaussian_filter(image, sigma=2)
        gaussian_pyramid.append(image)
    return gaussian_pyramid

def laplacian_stack(image, num_levels=5):
    gaussian_pyramid = gaussian_stack(image, num_levels)
    laplacian_pyramid = []
    for i in range(len(gaussian_pyramid) - 1):
        laplacian = gaussian_pyramid[i] - gaussian_filter(gaussian_pyramid[i + 1], sigma=2)
        laplacian_pyramid.append(laplacian)
    laplacian_pyramid.append(gaussian_pyramid[-1]) 
    return laplacian_pyramid

def display_stack(stack, title_prefix):
    num_levels = len(stack)
    cols = num_levels
    rows = 1

    plt.figure(figsize=(4 * cols, 4 * rows))
    for i, img in enumerate(stack):
        plt.subplot(rows, cols, i + 1)
        if 'Laplacian' in title_prefix:
            plt.imshow(img, cmap='gray')
            plt.title(f'{title_prefix} Level {i}')
        else:
            plt.imshow(img, cmap='gray')
            plt.title(f'{title_prefix} Level {i}')
        plt.axis('off')
    plt.tight_layout()
    plt.show()

# ##############################################################################
# ############### PART 2: FUN WITH FREQUENCIES #################################
# Part 2.4: Multiresolution Blending

def multiresolution_blend(image1, image2, mask, num_levels=5):
    # align and make two lapls
    image1_cropped, image2_cropped = align_images(image1, image2)
    laplacian_pyramid1 = laplacian_stack(image1_cropped, num_levels)
    laplacian_pyramid2 = laplacian_stack(image2_cropped, num_levels)
    gaussian_pyramid_mask = gaussian_stack(mask, num_levels)

    # blend
    blended_pyramid = [blend_images(gaussian_pyramid_mask[l], laplacian_pyramid1[l], laplacian_pyramid2[l]) 
                       for l in range(num_levels)]

    blended_image = reconstruct_from_pyramid(blended_pyramid)
    show_image(blended_image, "Blended Image")

# ##############################################################################
# ############### TESTING ######################################################

if __name__ == "__main__":
    # 1.1: finite difference operator
    finite_diff(cameraman) 

    # 1.2: derivative of gaussian
    deriv_of_gaussian(cameraman)  

    # 2.1: unsharp masking
    unsharp_mask(image1)  # apple
    # unsharp_mask(image2) 
    unsharp_mask(custom_img1, sigma=10.0, strength=0.25)  # owl

    # 2.2: hybrid image
    hybrid(image1, image2, sig_high, sig_low)  # apple, orange
    hybrid(custom_img1, custom_img2, sigma_high=10, sigma_low=3.5)  # owl, ball
    fourier_transform(cameraman)

    # 2.3: gaussian and laplacian stacks
    gauss_stack = gaussian_stack(image1, num_levels=5)  # apple
    lap_stack = laplacian_stack(image2, num_levels=5)  # orange

    display_stack(gauss_stack, 'gaussian')
    display_stack(lap_stack, 'laplacian')

    # 2.4: multiresolution blending
    mask = np.zeros_like(image1)
    mask[:, :mask.shape[1] // 2] = 1
    show_image(mask, "Blending Mask")
    multiresolution_blend(image1, image2, mask)
    multiresolution_blend(custom_img1, custom_img2, mask)
